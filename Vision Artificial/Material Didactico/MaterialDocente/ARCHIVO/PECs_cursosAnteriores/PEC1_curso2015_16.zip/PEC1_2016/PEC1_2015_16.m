%% PEC1 2015-2016


% Nota: a continuaci�n se propone la soluci�n a las PEC1.
% * El c�digo no est� optimizado para facilitar la comprensi�n por parte del alumno.
% Se utiliza el operador imtool para que el alumno pueda interactuar con la
% imagen y tener acceso a m�s informaci�n. En condiciones normales, se
% utilizar�a imshow, que es menos costosa computacionalmente y permite a�adir informaci�n
% de manera incremental.
% * Se aconseja ir ejecutando el c�digo paso a paso para ir viendo los
% resultados producidos por cada operador. Para ello, poned un break point
% en la primera l�nea de c�digo, y luego ejecutar (run + analisis + step + an�lisis + step ... )
% * Al utilizar imtool, si la imagen es muy peque�a, habr� que hacer zoom
% en la imagen para visualizar los resultados.





%% ********************************************************************************************
%% *************** CONVOLUCIONES Y OPERACIONES MORFOL�GICAS Im�genes binarias *****************
%% ********************************************************************************************

I = [...
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 0
0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1 0 0 0 0 0
0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 1 1 1 0 1 1 1 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 0 0 0 0 0
0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

SE = strel('square',3)

imtool(I); %% Como la imagen es muy peque�a, habr� que hacer zoom.


% a) dilataci�n (Imagen1, SE)
Rd = imdilate(I,SE);
imtool(Rd); 

% b) erosi�n (Imagen1, SE)
Re = imerode(I,SE);
imtool(Re); 

% c) dilataci�n (erosi�n (Imagen1, SE))
Rcierre = imerode(Rd,SE);   % la operaci�n de cierre es un filtro asociado a la forma del objeto que permite cerrar agujeros y grietas del objeto
imtool(Rcierre);

% d) erosion (dilatacion(Imagen1, SE))
Rapertura= imdilate(Re,SE);       % la operaci�n de apertura es un filtro asociado a la forma del objeto que permite eliminar salientes estrechos del objeto
imtool(Rapertura);

% e) dilataci�n (Imagen1, SE) - Imagen1
Rc_ext = Rd - I;% contorno exterior
imtool(Rc_ext );

% f)  Imagen1 - erosi�n(Imagen1, SE) 
Rc_int = I - Re;  % contorno interior
imtool(Rc_int );


% Comentario: El objetivo del ejemplo era que aprendierais c�mo se calculaba la dilataci�n y la erosi�n, por lo que se ha trabajado con im�genes peque�as
% en las que el elemento estructurante tiene un tama�o comparable al del objeto. Esto hace que no se aprecien bien las caracter�sticas de los
% operadores de morfolog�a matem�tica.


imtool close all




%% ******************************************************************************************************
%% *************** CONVOLUCIONES Y OPERACIONES MORFOL�GICAS Im�genes en niveles de gris *****************
%% ******************************************************************************************************



%% Convoluci�n
I = [...
    0 0 0 0 0 0 0 0 0 0 0 0
    0 0 0 0 0 0 0 1 0 0 0 0
    0 0 0 1 1 1 1 1 0 0 0 0
    0 0 0 1 1 1 1 0 0 0 0 0
    0 0 0 1 1 1 0 0 0 0 0 0
    0 0 0 2 2 2 2 2 2 0 0 0
    0 0 0 3 3 3 0 0 0 0 0 0
    0 0 0 3 3 3 0 0 0 0 0 0
    0 0 0 5 5 5 5 5 0 0 0 0
    0 0 0 0 0 0 5 5 5 0 0 0
    0 0 0 0 0 0 0 0 0 0 0 0
    0 0 0 0 0 0 0 0 0 0 0 0
    0 0 0 0 0 0 0 0 0 0 0 0    ];
    
    
    

imtool(I,[0,5]); % observe que se indica el rango de valores que se desea visualizar (entre 0 y 5). 

K = ones(3,3)/9;


Rconv = conv2(I,K,'same');

imtool(Rconv,[0,5]); %% para visualizarlo en la misma escala que la I original

% para visualizar una imagen cuando no se sabe su rango 
imtool(Rconv,[floor(min(Rconv(:))), ceil(max(Rconv(:)))]);   % Rconv(:)  pasa la matriz de 2D a 1D.


% R =
% 
%          0         0         0         0         0         0    0.1111    0.1111    0.1111         0         0         0
%          0         0    0.1111    0.2222    0.3333    0.3333    0.4444    0.3333    0.2222         0         0         0
%          0         0    0.2222    0.4444    0.6667    0.6667    0.6667    0.4444    0.2222         0         0         0
%          0         0    0.3333    0.6667    1.0000    0.8889    0.6667    0.3333    0.1111         0         0         0
%          0         0    0.4444    0.8889    1.3333    1.2222    1.0000    0.7778    0.4444    0.2222         0         0
%          0         0    0.6667    1.3333    2.0000    1.5556    1.1111    0.6667    0.4444    0.2222         0         0
%          0         0    0.8889    1.7778    2.6667    2.0000    1.3333    0.6667    0.4444    0.2222         0         0
%          0         0    1.2222    2.4444    3.6667    3.0000    2.3333    1.1111    0.5556         0         0         0
%          0         0    0.8889    1.7778    2.6667    2.8889    3.1111    2.7778    1.6667    0.5556         0         0
%          0         0    0.5556    1.1111    1.6667    2.2222    2.7778    2.7778    1.6667    0.5556         0         0
%          0         0         0         0         0    0.5556    1.1111    1.6667    1.1111    0.5556         0         0
%          0         0         0         0         0         0         0         0         0         0         0         0
%          0         0         0         0         0         0         0         0         0         0         0         0
         
         

%% dilate - erode imagen 
SE = strel('square',3)
Re = imerode(I,SE);
Rd = imdilate(Re,SE);
imtool(Rd,[0,5]); %% para visualizarlo en la misma escala que la I original

% I =
% 
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     1     0     0     0     0
%      0     0     0     1     1     1     1     1     0     0     0     0
%      0     0     0     1     1     1     1     0     0     0     0     0
%      0     0     0     1     1     1     0     0     0     0     0     0
%      0     0     0     2     2     2     2     2     2     0     0     0
%      0     0     0     3     3     3     0     0     0     0     0     0
%      0     0     0     3     3     3     0     0     0     0     0     0
%      0     0     0     5     5     5     5     5     0     0     0     0
%      0     0     0     0     0     0     5     5     5     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
% 
% Re
% 
% Re =
% 
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     1     0     0     0     0     0     0     0
%      0     0     0     0     1     0     0     0     0     0     0     0
%      0     0     0     0     1     0     0     0     0     0     0     0
%      0     0     0     0     2     0     0     0     0     0     0     0
%      0     0     0     0     3     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
% 
% Rd
% 
% Rd =
% 
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     1     1     1     0     0     0     0     0     0
%      0     0     0     1     1     1     0     0     0     0     0     0
%      0     0     0     1     1     1     0     0     0     0     0     0
%      0     0     0     2     2     2     0     0     0     0     0     0
%      0     0     0     3     3     3     0     0     0     0     0     0
%      0     0     0     3     3     3     0     0     0     0     0     0
%      0     0     0     3     3     3     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0


%% dilate - erode imagen en niveles de gris
SE = strel('square',3)
Rd2 = imdilate(I,SE);
Re2 = imerode(Rd2,SE);
imtool(Re2,[0,5]); %% para visualizarlo en la misma escala que la I original

% I =
% 
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     1     0     0     0     0
%      0     0     0     1     1     1     1     1     0     0     0     0
%      0     0     0     1     1     1     1     0     0     0     0     0
%      0     0     0     1     1     1     0     0     0     0     0     0
%      0     0     0     2     2     2     2     2     2     0     0     0
%      0     0     0     3     3     3     0     0     0     0     0     0
%      0     0     0     3     3     3     0     0     0     0     0     0
%      0     0     0     5     5     5     5     5     0     0     0     0
%      0     0     0     0     0     0     5     5     5     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
% 
% Rd2
% 
% Rd2 =
% 
%      0     0     0     0     0     0     1     1     1     0     0     0
%      0     0     1     1     1     1     1     1     1     0     0     0
%      0     0     1     1     1     1     1     1     1     0     0     0
%      0     0     1     1     1     1     1     1     1     0     0     0
%      0     0     2     2     2     2     2     2     2     2     0     0
%      0     0     3     3     3     3     3     2     2     2     0     0
%      0     0     3     3     3     3     3     2     2     2     0     0
%      0     0     5     5     5     5     5     5     5     0     0     0
%      0     0     5     5     5     5     5     5     5     5     0     0
%      0     0     5     5     5     5     5     5     5     5     0     0
%      0     0     0     0     0     5     5     5     5     5     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
% 
% Re2
% 
% Re2 =
% 
%      0     0     0     0     0     0     0     1     0     0     0     0
%      0     0     0     0     0     0     0     1     0     0     0     0
%      0     0     0     1     1     1     1     1     0     0     0     0
%      0     0     0     1     1     1     1     1     0     0     0     0
%      0     0     0     1     1     1     1     1     0     0     0     0
%      0     0     0     2     2     2     2     2     2     0     0     0
%      0     0     0     3     3     3     2     2     0     0     0     0
%      0     0     0     3     3     3     2     2     0     0     0     0
%      0     0     0     5     5     5     5     5     0     0     0     0
%      0     0     0     0     0     0     5     5     5     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0     0     0     0



% Understanding Dilation and Erosion
% Morphology is a broad set of image processing operations that process images based on shapes. Morphological operations apply a structuring
% element to an input image, creating an output image of the same size. In a morphological operation, the value of each pixel in the output 
% image is based on a comparison of the corresponding pixel in the input image with its neighbors. By choosing the size and shape of the 
% neighborhood, you can construct a morphological operation that is sensitive to specific shapes in the input image.
% 
% The most basic morphological operations are dilation and erosion. Dilation adds pixels to the boundaries of objects in an image, while 
% erosion removes pixels on object boundaries. The number of pixels added or removed from the objects in an image depends on the size and 
% shape of the structuring element used to process the image. In the morphological dilation and erosion operations, the state of any given 
% pixel in the output image is determined by applying a rule to the corresponding pixel and its neighbors in the input image. The rule used 
% to process the pixels defines the operation as a dilation or an erosion. This table lists the rules for both dilation and erosion.
% 
% Rules for Dilation and Erosion 
% Operation
% Rule
% Dilation
% The value of the output pixel is the maximum value of all the pixels in the input pixel's neighborhood. In a binary image, 
% if any of the pixels is set to the value 1, the output pixel is set to 1.

% Erosion
% The value of the output pixel is the minimum value of all the pixels in the input pixel's neighborhood. In a binary image, 
% if any of the pixels is set to 0, the output pixel is set to 0.
% The following figure illustrates the dilation of a binary image. Note how the structuring element defines the neighborhood of the pixel 
% of interest, which is circled. (See Understanding Structuring Elements for more information.) The dilation function applies the appropriate 
% rule to the pixels in the neighborhood and assigns a value to the corresponding pixel in the output image. In the figure, the morphological
% dilation function sets the value of the output pixel to 1 because one of the elements in the neighborhood defined by the structuring element 
% is on.

% The following figure illustrates this processing for a grayscale image. The figure shows the processing of a particular pixel in the input 
% image. Note how the function applies the rule to the input pixel's neighborhood and uses the 
%% highest value of all the pixels in the neighborhood 
% as the value of the corresponding pixel in the output image.
%% (the lowest for erosion)


%% 


imtool close all



%% ***************************************************************************
%% *****************************   SATURNO    ********************************
%% ***************************************************************************


%% Imagen original.
imageinfo('saturno.tiff');
I = imread('saturno.tiff');

%% Hay que tener en cuenta las limitaciones de los distintos formatos a la hora de operar.
%% el mejor formato para operar es double con valores entre 0 y 1.
%% Para visualizar a veces hay que utilizar uint8. 
 
I = double(I(:,:,1));  % nos quedamos con solo un canal porque es una imagen en niveles de gris
whos I
imtool(I,[0,255])

%% Cambio de escala con distintos factores en x e y  (2 en x ,1 en y). 
I1 = imresize(I,[size(I,1), 2*size(I,2)]);
imshow(uint8(I1));
%% Rotaci�n de la imagen 15�
I2 = imrotate(I1, 15);
imshow(uint8(I2)) % otra opci�n:  imshow(I2,[0,255])


%% --------------------------- An�lisis de la imagen ---------------------------------

%% En el histograma se aprecia la cantidad de pixeles en cada rango de valores de intensidad, por tanto, se puede apreciar 
%% si la imagen est� clara u oscura, PERO NO SE PUEDE APRECIAR EL TIPO DE RUIDO. 
imhist(uint8(I))

%% An�lisis de la vecindad: analizando las relaciones de unos pixeles con sus vecinos. 
%% Matriz de co-ocurrencia: los valores m�s frecuentes est�n en la diagonal principal, 
%% luego el valor de cada pixel es muy parecido al de sus vecinos. Se considera por tanto que 
%% no hay cambios muy bruscos y por tanto la imagen es, en general, de baja frecuencia. 
%% Observese que este an�lisis es un an�lisis global sobre toda la imagen, podr�a darse el caso
%% que una peque�a regi�n de la imagen tuviera caracter�sticas distintas y no resultara apreciable en este an�lisis.
glcm = graycomatrix(uint8(I), 'NumLevels', 256/8);
imtool(glcm)


%% Filtro por convoluci�n
K = ones(3,3)/9;
Rconv = conv2(I,K,'same');
imtool(Rconv,[0,255]);


%% filtro por Apertura (dejar� un granulado del tama�o del elemento estructurante)
SE = strel('square',3)
Re = imerode(I,SE);
Rde = imdilate(Re,SE);
imtool(Rde,[0,255]);


%% Filtro de mediana  (uno de los filtros m�s conveniente)
Rmedian = medfilt2(I); % ventana de 3x3
imtool(Rmedian,[0,255]);

Rmedian = medfilt2(I, [5,5]); % tomando una ventana mayor
imtool(Rmedian,[0,255]);


%% filtro gaussiano  (observad c�mo el granulado va desapareciendo al aumentar la desviaci�n t�pica del filtro)
for itSigma = 0.5:1:2.5
    Igauss = imgaussfilt(I, itSigma );
    imtool(Igauss, [0,255])
    %pause;  % descomentar para parar en cada iteraci�n 
end


%% Obtenga los bordes de los objetos utilizando el m�todo m�s conveniente 
% cuando se habla de bordes de los objetos, nos estamos refiriendo a los
% bordes m�s significativos que hay en la imagen y que est�n relacionados
% con los objetos de inter�s. No siempre es posible distinguir entre borde
% de objeto y cambio de intensidad significativo en la imagen, pero podemos
% suponer que los bordes de los objetos tienen una continuidad. Esa es la
% diferencia entre un detector de bordes tipo Canny y un simple detector de
% contraste. Sin embargo, si realizamos un preprocesado conveniente de la
% imagen para eliminar los contrastes en las zonas que no son de inter�s,
% podemos aproximar un operador por otro. 

% En nuestro caso, al suavizar la imagen, hemos eliminado el ruido
% gaussiano y solo quedan como significativos los bordes de saturno. 
SE = strel('disk',3)
Iborde = Igauss - imerode(Igauss,SE);
imtool(Iborde);

% Obs�rvese que el resutlado son valores entre 0 y 1, por lo que hay que aplicar 
% un threshold para decidir qu� se considera borde y qu� no.


IbordeCanny = edge(Igauss, 'Canny');
imtool(IbordeCanny);

IbordeCanny = edge(Igauss, 'Canny', [0.1, .2]);  % la importancia de configurar bien los par�metros.
imtool(IbordeCanny);



imtool close all



%% ***************************************************************************
%% **************************** llave inglesa ********************************
%% ***************************************************************************


%% imagen para segmentaci�n, c�lculo de distancias y extracci�n del contorno
I = imread('llave_inglesa.png');
I = double(I(:,:,1));
imtool(I,[0,255]);

%% obs�rvese   I(:) convierte la imagen en un vector. Esto premite realizar operaciones que no tienen en cuenta la posici�n 2D de los pixeles.
% Por ejemplo, el c�lculo del m�ximo se simplifica:
valorMaximo2 = max(I(:));     % equivale a  valorMaximo1 =  max(max(I))    % 

% Segmentaci�n de la imagen
level = graythresh(I/256);  % estos operadores requieren valores normalizados entre 0 y 1
IsegOtsu = ~im2bw(I/256,level);
imtool(IsegOtsu)


Iseg = ~im2bw(I/256,234/256);
figure(1); imshow(Iseg)


mapaDistancias = bwdist(Iseg) - bwdist(~Iseg);

%% las im�genes pueden representar distinta informaci�n, no solo capturar el nivel de luz en un punto.
% Obs�rvese que el mapa de distancias es una nueva imagen en el que el valor de la intensidad de los pixeles est� asociado a la distancia al objeto.
imtool(mapaDistancias)    % para visualizar todo el rango, utilizar: imtool(mapaDistancias, [min(mapaDistancias(:)), max(mapaDistancias(:))]) 
% observe que el rango de visualizaci�n inicial (contrast) hace que la imagen se vea en blanco y negro. 
% Si se ajusta el contraste se contraste, se ver� una gradaci�n de la intensidad correspondiente a la variaci�n de la distancia al objeto.


%% El punto m�s profundo en el objeto corresponder� a la mayor distancia negativa
[valorPuntoMasProfundo, indPuntoMasProfundo ] = min(mapaDistancias(:));
[posy,posx] = ind2sub(size(mapaDistancias), indPuntoMasProfundo);

figure(2); 
imshow(uint8(I)); 
hold on;
plot(posx,posy,'r*');   
%% Nota: representaci�n (x,y) vs (filas, columnas)
% Cuidado con el convenio de coordenadas, unos operadores utilizan (x,y) y
% otros (filas, columnas). Las filas corresponden a y; las columnas a x (por lo que se intercambia el orden).


%% contorno del objeto
% El contorno del objeto se puede obtener utilizando distintos operadores
% de detecci�n de bordes. Sin embargo, si ya tenemos el mapa de distancias,
% ya tenemos calculado el borde del objeto. Si lo queremos interior,
% cogeremos los puntos de distancia -1, si lo queremos exterior, los de
% distancia +1. (por la forma de calcular la distancia, no existen puntos
% de distancia 0 al contorno).
contorno = (mapaDistancias==-1);

figure;
imshow(contorno)
hold on;
plot(posx,posy,'r*');   

%% *** FIN ***