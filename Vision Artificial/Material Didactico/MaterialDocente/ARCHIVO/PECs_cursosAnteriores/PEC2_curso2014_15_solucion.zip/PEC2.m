%% (c) Mariano Rincon - Dpto Inteligencia Artificial - UNED
%% Soluci??n a la PEC2 curso 2014-2015 asignatura visi??n artificial grado inform??tica.

%% NOTA: se recomienda utilizar el interfaz visual de OCTAVE:    octave --force-gui
 

% pkg load image
ejercicio2 = 1;
ejercicio3 = 1;









if ejercicio2


I0 = imread('I3T_200_T1.png');
I0 = I0(:,:,1);
I1 = zeros(908,1269);
I1 (1:907,1:1269) = I0(1:907,1:1269);
clear I0;

I2 = imread('I3T_200_WM_orig.png');
I2 = I2(:,:,1);

I3 = imread('I3T_200_WMconObjetos.png');    % (255,0,228) -> pink; (255,255,0) = amarillo



%% 1.-  blob mayor
Ibw = I2>125;
L = bwlabel(Ibw);
R = regionprops(L);
[val, indMax] = max(cat(1,R.Area));

IBWM1 = zeros(size(Ibw));
IBWM1(find(L==indMax)) = 1;
imshow(IBWM1);

%% 2.- contorno y esqueleto
if 1
    IBWM1_contour = IBWM1 - bwmorph(IBWM1,'erode');
    
    IBWM1_skell0 = bwmorph(IBWM1,'skel', Inf);
    %IBWM1_skell01 = bwmorph(IBWM1,'skel-lantuejol', Inf);
    %IBWM1_skell02 = bwmorph(IBWM1,'skel-pratt',Inf);

    endpoints = 0;
    IBWM1_skell = IBWM1_skell0;
    if endpoints
    IT = 27;
    IendPoints = bwmorph(IBWM1_skell0,'endpoints');
    for it=1:IT
        IBWM1_skell= IBWM1_skell - IendPoints ;
        IendPoints = bwmorph(IBWM1_skell,'endpoints');
    end
    end
end


%?skel-lantuejol?
%?skel-pratt?


%% 3.- regiones amarilla y rosa
Ipink = zeros(size(I3(:,:,1)));
Ipink   (find( I3(:,:,1)==255 &  I3(:,:,2)==0 & I3(:,:,3)==228 ) ) = 1; 

Iyellow = zeros(size(I3(:,:,1)));
Iyellow (find(I3(:,:,1)==255 & I3(:,:,2)==255 & I3(:,:,3)==0) ) = 1; 


%% 4.- zona ventricular
indYe = find (Iyellow>0);
L2 = bwlabel(~Ibw);
ind = unique( L2(indYe) );

IBWM2 = zeros(size(Ibw));
IBWM2(find(L2==ind)) = 1;


%% 5.- caracter?sticas de los objetos rosas
Lpink = bwlabel(Ipink);
Rpink = regionprops(Lpink, I1, 'Area', 'Perimeter', 'BoundingBox' , 'Centroid', 'MaxIntensity', 'MeanIntensity', 'MinIntensity');
kk=0; 

%% 6.- distancias de los objetos rosas
 %mapa de distancias al contorno 
Dext = bwdist ( IBWM1);
Dint = bwdist (~IBWM1);
DBWM1 = Dext - Dint;

for itB = 1:length(Rpink)
    ind = find (Lpink==itB);
    DistContBlob_max(itB) = max(DBWM1(ind));
    DistContBlob_min(itB) = min(DBWM1(ind));
    DistContBlob_mean(itB) = mean(DBWM1(ind));
end


%% 7.- distancias de los objetos rosas
 %mapa de distancias al esqueleto 
DBWM2 = bwdist ( IBWM1_skell);
for itB = 1:length(Rpink)
    ind = find (Lpink==itB);
    DistSkelBlob_max(itB)  = max (DBWM2(ind));
    DistSkelBlob_min(itB)  = min (DBWM2(ind));
    DistSkelBlob_mean(itB) = mean(DBWM2(ind));
end


%% 8.- distancia al blob BWM2
DBWM3 = bwdist ( IBWM2 );
for itB = 1:length(Rpink)
    ind = find (Lpink==itB);
    DistBWM2_max(itB)  = max (DBWM3(ind));
    DistBWM2_min(itB)  = min (DBWM3(ind));
    DistBWM2_mean(itB) = mean(DBWM3(ind));
end


%% 9.- caracter?sticas con la vecindad

for itB = 1:length(Rpink)
    Ib = zeros(size(Ipink));
    Ib(find(Lpink==itB))=1;
    relacionVecindadPink (itB) = analisisVecindad(Ib, I1);
end


% 10.- selecci?n del blob con menor relaci?n area/per?metro
A = cat(1, Rpink.Area);
P = cat(1, Rpink.Perimeter);
relAP = A./P;
[val, indMin] = min(relAP);

IBmin = zeros(size(Lpink));
IBmin (find(Lpink==indMin)) = 1; 

Icontorno = IBmin - bwmorph(IBmin,'erode');
indC = find(Icontorno==1);

% pintar en amarillo 1
imshow(uint8(I1));
hold on;
[f,c] = ind2sub(size(I1),indC);
plot(c,f,'y.');


% pintar en amarillo 2
Ir = I1/2;
Ir(indC) = 255;
imshow(uint8(Ir));


kk=0;

end


if ejercicio3

%% formato de la imagen (analisis de la variable y del contenido)
I1 = imread('monedas.png');
I1 = I1(:,:,1);

imfinfo('monedas.png')
whos I1  % uint8, 325x563x3   => imagen de tres canales (RGB), al ser uint8 el rango posible es [0 .. 255]
maxmin(I1)    % rango del contenido de la imagen  [27,255]
figure(1);
imhist(I1);    % histograma con dos picos, alrededor de 100 y en 255, que corresponden a los objetos y al fondo respectivamente
               % Si quisieramos segmentar los objetos, deberiamos establecer un threshold entorno a 160-170 (por analisis visual).

I2 = medfilt2(I1,[9,9]);
figure(1);
imshow(I2);

Ib = im2bw (I2, graythresh (I2)); % paso a imagen binaria
imshow(Ib);

SE = strel ("disk",1);
Ie = imerode(Ib,SE);
Ic = Ib-Ie;

imshow(Ic)

R = [50:10:125];
H = houghtf(Ic, "circle", R);
f = [];
c = [];
for itR = 1:length(R)
  [fit, cit] = immaximas (H(:,:,itR), 5,100);
  f = [f; fit];
  c = [c; cit];
end
figure(2);
imshow(Ic);
hold on;
plot(c,f,'r*');
 
 
kk=0; 


end







