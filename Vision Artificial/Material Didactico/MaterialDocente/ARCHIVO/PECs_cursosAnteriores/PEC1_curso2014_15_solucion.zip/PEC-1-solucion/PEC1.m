%% (c) Mariano Rincon - Dpto Inteligencia Artificial - UNED
%% Solución PEC1 asignatura visión artificial grado informática. 

%% NOTA: se recomienda utilizar el interfaz visual de OCTAVE:    octave --force-gui
 

% pkg load image
ejercicio1 = 1;
ejercicio2 = 1;
ejercicio3 = 1;



%%%%%%%%%%%%%%%%%
%% Ejercicio 1 %% 
%%%%%%%%%%%%%%%%%
if ejercicio1

% Ejercicio1.4

K = [-3 0 3; -10 0 10; -3 0 3];

I1 = zeros(11,10);
I = [1 1 1 1; 1 1 1 1; 1 1 1 1; 2 2 2 2; 3 3 3 3; 5 5 5 5];
I1(4:9,4:7) = I;

Iout = conv2(I1, K, "same") 



%% otra prueba. Sobre una imagen que solo tiene un pixels a 1 para analizar el comportamiento más fácilmente.
K1 = [1 2 3; 4 5 6; 7 8 9];
I2 = zeros(11,10);
I2(5,7)=1; 
Iout1 = conv2(I2, K1, "same") 


clear Iout
clear I
clear I1
end

%%%%%%%%%%%%%%%%
%% Ejercicio 2 %% 
%%%%%%%%%%%%%%%%
if ejercicio2

%% formato de la imagen (analisis de la variable y del contenido)

I = imread('objetosGeometricos1_conRuido.png');

imfinfo('objetosGeometricos1_conRuido.png')
whos I  % uint8, 325x563x3   => imagen de tres canales (RGB), al ser uint8 el rango posible es [0 .. 255]
maxmin(I)    % rango del contenido de la imagen  [27,255]
imhist(I);    % histograma con dos picos, alrededor de 100 y en 255, que corresponden a los objetos y al fondo respectivamente
              % Si quisieramos segmentar los objetos, deberiamos establecer un threshold entorno a 160-170 (por analisis visual).

     
     
%% resize: ojo con el convenio de octave/matlab para metrices e imágenes:
% Matrices: (filas, columnas) o (y,x) 
% Imagenes (x,y)   y  plot (x,y)

I1 = imresize(I,[size(I,1)*1.5, size(I,2)*3]); % (x*3, y*1.5)

figure(1);
imshow(I);
figure(2);
imshow(I1);


%% rotate
I2 = imrotate(I1, 40);

figure(3);
imshow(I2);


%% paso a niveles de gris
I3 = rgb2gray(I2);

figure(4);
imshow(I3);


%% elimnar ruido: varias alternativas. Ninguna lo elimna completamente si no sabemos la fuente.
% Para analizar el error, es necesario analizar la distribucion local de los valores en la imagen.

% Comprobamos si hay grandes variaciones en la vecindad (esto nos define el tipo de ruido suponiendo objetos con color uniforme)
% la ayuda de octave para el operador graycomatrix es pobre, pero si buscáis en matlab, hay m´ss documentación
Ig = rgb2gray(I);
G = graycomatrix(double(Ig),256,[1 2],[0:1:7]); % 256 niveles, distancias 1 y 2, angulos 0,45,90, ...
G_all_angles = sum (G,4); %suma de todos los valores calculados para los distintos angulos 
G_all_angles_all_distances = sum (G_all_angles, 3); % suma de todas las distancias
% en la imagen se puede ver que la matriz de coocurrencia muestra valores en la diagonal, lo que quiere decir que los valores de los vecinos son cercanos
imshow(mat2gray(G_all_angles_all_distances)*1500); % el 1500 es para subir los niveles para que sean visibles


%% con el analisis anterior, parece apropiado utilizar un filtro de gaussiana o de mediana
I4 = medfilt2(I3,[9,9]);
figure(5);
imshow(I4);




% Ejercicio 2.5: contorno de los objetos: se puede realizar por detección de bordes o después de la segmentación de los objetos.

% prueba 1: dilate sobre niveles de gris
Id = imdilate(I4, ones(3,3));
Icontour = Id-I4;
figure(6);
imshow(Icontour);

% prueba 2: deteccion de bordes Canny 
% (ojo, no vale con poner los valores por defecto, la configuracion de los operadores es importante)
Icontour = edge(I4, "Canny", 5, 4);
figure(7);
imshow(Icontour);

% prueba 3: deteccion de bordes Canny
Icontour = edge(I4, "Canny", 3, 4);
figure(8);
imshow(Icontour);

% prueba 4: deteccion de bordes Sobel
Icontour = edge(I4, "Sobel", 60);
figure(9);
imshow(Icontour);


% prueba 5: deteccion de bordes LoG (no obtiene nada)
Icontour = edge(I4, "LoG", 2);
figure(10);
imshow(Icontour);


% prueba 6: deteccion de bordes sobre imagen binaria ()
[h4,x4] = imhist(I4);

figure(11);
plot(x4,h4);

th = graythresh(I4);

Ib1 = im2bw(I4,200/255);
Ib2 = im2bw(I4,100/255);
Ib = Ib2-Ib1;
figure(12);
imshow(Ib);


Id = bwmorph (Ib, "dilate", 1);
Ic = Id-Ib;
figure(13);
imshow(Ic);

figure(14); %% ojo, que lo que se ve, puede no ser la realidad. Mira lo que pasa cuando se hace zoom!!!
imshow(Ic(346:600, 806:1000));


%% Luego parece que el operador de Canny y pasar la imagen a binaria (pues queremos solo los limites de los objetos) proporciona los mejores resultados.

clear I*
close all
end






%%%%%%%%%%%%%%%%%
%% Ejercicio 3 %% 
%%%%%%%%%%%%%%%%%
if ejercicio3

I = imread("I3TWM_200.png");

%% analisis de la imagen
whos I  % uint8, 158x341
maxmin(I)    % rango [0,255]
imhist(I);    % histograma con dos picos en 0 y en 255, que corresponden a los extremos y pt, a las probabilidades 0 y 1 respectivamente

%% pixeles con probabilidad 0.5 => valor 256/2 = 128. Como empieza en 0 -> v = 127.  
[ind05y,ind05x] = find(I==127)
figure;
imshow(I);
if ~isempty(ind05x)
hold on;
plot(ind05x,ind05y,'r*');  % no encuentra nada porque no hay ningún pixel con ese valor
end

[ind05y,ind05x] = find(I>120 & I <130)   % cogemos un rango de valores (entre 120 y 130)
figure;
imshow(I);
if ~isempty(ind05x)
hold on;
plot(ind05x,ind05y,'r.');  %con 'r*' saldrian mas gruesos
end



%% contorno del objeto
% tambien se puede obtener el contorno con bwboundaries y con regioprops. 
% Aqui lo hacemos con una erosion (operacion morfologica)
Id = bwmorph (Ib, "erode", 1);  
Icontour = Ib-Id; % los puntos pertenecen al objeto


%% distancias (positivas fuera del objeto y negativas dentro del objeto)
Ib = im2bw (I, graythresh (I)); % paso a imagen binaria
Dext = bwdist (Ib);  % distancia pixeles exteriores al objeto

Ib_inv = ~Ib;   % 1-Ib;  Imagen inversa (ahora el objeto es el fondo y el fondo el objeto)
Dint = bwdist(Ib_inv); % distancia puntos interiores

D = Dext - Dint;  % imagen composicion de distancias. Negativas las interiores (por eso se resta).

ID = mat2gray(D);
figure(1);
imshow(ID);   % como no se puede analizar los valores, no se aprecia gran cosa.

ID = mat2gray(D); % normaliza D al rango [0..1]
figure(3);
imshow(min(1, ( ID + double(Icontour))));  % vemos el borde del objeto superpuesto sobre la imagen de distancias
% ojo, hay que tener cuidado con el formato de las imagenes (binary, double, uint8, ...)
% y con el rango de valores dentro de la imagen ([0..1], [0..255], [-a..+b]...)


% comprobemos su histograma de distancias
% observad que el histograma va de 0 a 1. MAL!!!!! El problema es que imhist solo trabaja con imagenes en escala de grises!
[countkk,xxkk] = imhist(D,20);
figure(4); 
plot(xxkk,countkk) ; 
% este operador si es correcto
[count,xx] = hist(D(:),20);  % observad el (:). Esto se hace para que se trate la matriz como un vector de 1 dimension. Comprobad que el resultado no es correcto si no se pone.
figure(4);
plot(xx,count) % ahora si es correcto. Valores entre -20 y 60 aprox.


%% vamos a identificar los puntos mas interiores (aquellos con distancia mayor al borde)
IL = bwlabel(Ib); % imagen de etiquetas. Los objetos que nos interesan son m´as claros que el fondo. Por eso cogemos Ib. Si no, tendriamos que haber cogido la inversa.
figure(5); 
imshow(Ib);
hold on;
for itL=1:max(IL(:))
	indpixels = find(IL==itL);  % pixeles del objeto bajo analisis
	distPixels = D(indpixels);  % distancias de esos pixeles
	[mindist, indPuntoMasInterior] = min(distPixels); % minimo. solo devuelve el primer minimo!
	indPuntoMasInterior_all = find(distPixels == mindist); % para coger todos los minimos del objeto.
	[y,x] = ind2sub(size(Ib),indpixels(indPuntoMasInterior_all)); % localizar las coordenadas en la imagen
	plot(x,y,'r*'); % pintar
end

clear all

end






